package exceptions;

public class ItemNotFoundError extends Exception {
    public ItemNotFoundError(String message) {
        super(message);
    }
}